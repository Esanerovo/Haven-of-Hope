"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Search, Filter } from "lucide-react"

interface ProjectFiltersProps {
  categories: string[]
  statuses: string[]
  onFilterChange: (filters: {
    search: string
    category: string
    status: string
  }) => void
}

export function ProjectFilters({ categories, statuses, onFilterChange }: ProjectFiltersProps) {
  const [search, setSearch] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")

  const handleFilterChange = (
    newFilters: Partial<{
      search: string
      category: string
      status: string
    }>,
  ) => {
    const updatedFilters = {
      search: newFilters.search ?? search,
      category: newFilters.category ?? selectedCategory,
      status: newFilters.status ?? selectedStatus,
    }

    if (newFilters.search !== undefined) setSearch(newFilters.search)
    if (newFilters.category !== undefined) setSelectedCategory(newFilters.category)
    if (newFilters.status !== undefined) setSelectedStatus(newFilters.status)

    onFilterChange(updatedFilters)
  }

  return (
    <div className="space-y-6">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Search projects..."
          value={search}
          onChange={(e) => handleFilterChange({ search: e.target.value })}
          className="pl-10"
        />
      </div>

      {/* Category Filters */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          <span className="font-medium text-foreground">Categories</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={selectedCategory === "all" ? "default" : "outline"}
            size="sm"
            onClick={() => handleFilterChange({ category: "all" })}
          >
            All
          </Button>
          {categories.map((category) => (
            <Button
              key={category}
              variant={selectedCategory === category ? "default" : "outline"}
              size="sm"
              onClick={() => handleFilterChange({ category })}
            >
              {category}
            </Button>
          ))}
        </div>
      </div>

      {/* Status Filters */}
      <div className="space-y-3">
        <span className="font-medium text-foreground">Status</span>
        <div className="flex flex-wrap gap-2">
          <Badge
            variant={selectedStatus === "all" ? "default" : "outline"}
            className="cursor-pointer"
            onClick={() => handleFilterChange({ status: "all" })}
          >
            All
          </Badge>
          {statuses.map((status) => (
            <Badge
              key={status}
              variant={selectedStatus === status ? "default" : "outline"}
              className="cursor-pointer"
              onClick={() => handleFilterChange({ status })}
            >
              {status.charAt(0).toUpperCase() + status.slice(1)}
            </Badge>
          ))}
        </div>
      </div>
    </div>
  )
}
