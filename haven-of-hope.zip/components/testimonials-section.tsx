"use client"

import { useState } from "react"
import { VideoTestimonial } from "./video-testimonial"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

const testimonials = [
  {
    id: "1",
    name: "Maria Santos",
    location: "Guatemala City, Guatemala",
    project: "Education for All",
    videoUrl: "/testimonial-maria.mp4",
    thumbnailUrl: "/maria-santos-testimonial-guatemala.jpg",
    quote:
      "Thanks to Haven of Hope, my children now have access to quality education. The new school has changed our entire community.",
    duration: "2:34",
  },
  {
    id: "2",
    name: "James Kimani",
    location: "Nairobi, Kenya",
    project: "Clean Water Initiative",
    videoUrl: "/testimonial-james.mp4",
    thumbnailUrl: "/james-kimani-testimonial-kenya.jpg",
    quote:
      "Before the well was built, we had to walk 5 kilometers for water. Now our village has clean water right here.",
    duration: "3:12",
  },
  {
    id: "3",
    name: "Fatima Rahman",
    location: "Dhaka, Bangladesh",
    project: "Sustainable Agriculture",
    videoUrl: "/testimonial-fatima.mp4",
    thumbnailUrl: "/fatima-rahman-testimonial-bangladesh.jpg",
    quote:
      "The new farming techniques have doubled our harvest. We can now feed our family and sell surplus at the market.",
    duration: "2:45",
  },
  {
    id: "4",
    name: "Carlos Mendoza",
    location: "Lima, Peru",
    project: "Renewable Energy",
    videoUrl: "/testimonial-carlos.mp4",
    thumbnailUrl: "/carlos-mendoza-testimonial-peru.jpg",
    quote:
      "Solar panels have brought electricity to our mountain village for the first time. Our children can study at night now.",
    duration: "3:28",
  },
  {
    id: "5",
    name: "Priya Sharma",
    location: "Mumbai, India",
    project: "Women Empowerment",
    videoUrl: "/testimonial-priya.mp4",
    thumbnailUrl: "/priya-sharma-testimonial-india.jpg",
    quote:
      "The vocational training program helped me start my own business. I can now support my family independently.",
    duration: "2:56",
  },
  {
    id: "6",
    name: "Andry Rakoto",
    location: "Antananarivo, Madagascar",
    project: "Healthcare Access",
    videoUrl: "/testimonial-andry.mp4",
    thumbnailUrl: "/andry-rakoto-testimonial-madagascar.jpg",
    quote:
      "The mobile clinic visits our village monthly. My daughter received life-saving treatment that wasn't available before.",
    duration: "3:15",
  },
]

export function TestimonialsSection() {
  const [currentPage, setCurrentPage] = useState(0)
  const testimonialsPerPage = 3
  const totalPages = Math.ceil(testimonials.length / testimonialsPerPage)

  const getCurrentTestimonials = () => {
    const start = currentPage * testimonialsPerPage
    return testimonials.slice(start, start + testimonialsPerPage)
  }

  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % totalPages)
  }

  const prevPage = () => {
    setCurrentPage((prev) => (prev - 1 + totalPages) % totalPages)
  }

  return (
    <section className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Stories of Hope</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Hear directly from the communities we serve about how your support has transformed their lives and created
            lasting change.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {getCurrentTestimonials().map((testimonial) => (
            <VideoTestimonial key={testimonial.id} {...testimonial} />
          ))}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-center gap-4">
          <Button variant="outline" onClick={prevPage} disabled={totalPages <= 1}>
            <ChevronLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          <div className="flex items-center gap-2">
            {Array.from({ length: totalPages }, (_, i) => (
              <Button
                key={i}
                variant={currentPage === i ? "default" : "outline"}
                size="sm"
                onClick={() => setCurrentPage(i)}
                className="w-10 h-10"
              >
                {i + 1}
              </Button>
            ))}
          </div>

          <Button variant="outline" onClick={nextPage} disabled={totalPages <= 1}>
            Next
            <ChevronRight className="h-4 w-4 ml-2" />
          </Button>
        </div>
      </div>
    </section>
  )
}
