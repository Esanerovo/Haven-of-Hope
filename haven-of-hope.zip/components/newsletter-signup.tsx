"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Mail, CheckCircle } from "lucide-react"

export function NewsletterSignup() {
  const [email, setEmail] = useState("")
  const [preferences, setPreferences] = useState({
    projectUpdates: true,
    impactReports: true,
    events: false,
    fundraising: false,
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubscribed, setIsSubscribed] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate newsletter signup
    await new Promise((resolve) => setTimeout(resolve, 1000))

    console.log("Newsletter signup:", { email, preferences })
    setIsSubscribed(true)
    setIsSubmitting(false)
  }

  const handlePreferenceChange = (key: string, checked: boolean) => {
    setPreferences((prev) => ({ ...prev, [key]: checked }))
  }

  if (isSubscribed) {
    return (
      <Card className="bg-primary/5 border-primary/20">
        <CardContent className="p-6 text-center">
          <CheckCircle className="h-12 w-12 text-primary mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-foreground mb-2">Thank You!</h3>
          <p className="text-muted-foreground">
            You've successfully subscribed to our newsletter. Check your email for a confirmation message.
          </p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Mail className="h-5 w-5 text-primary" />
          Stay Updated
        </CardTitle>
        <p className="text-muted-foreground">
          Subscribe to our newsletter to receive updates on our projects, impact stories, and ways to get involved.
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="newsletter-email">Email Address *</Label>
            <Input
              id="newsletter-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
            />
          </div>

          <div className="space-y-3">
            <Label className="text-sm font-medium">What would you like to receive?</Label>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="project-updates"
                  checked={preferences.projectUpdates}
                  onCheckedChange={(checked) => handlePreferenceChange("projectUpdates", checked as boolean)}
                />
                <Label htmlFor="project-updates" className="text-sm">
                  Project updates and success stories
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="impact-reports"
                  checked={preferences.impactReports}
                  onCheckedChange={(checked) => handlePreferenceChange("impactReports", checked as boolean)}
                />
                <Label htmlFor="impact-reports" className="text-sm">
                  Monthly impact reports
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="events"
                  checked={preferences.events}
                  onCheckedChange={(checked) => handlePreferenceChange("events", checked as boolean)}
                />
                <Label htmlFor="events" className="text-sm">
                  Event invitations and volunteer opportunities
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="fundraising"
                  checked={preferences.fundraising}
                  onCheckedChange={(checked) => handlePreferenceChange("fundraising", checked as boolean)}
                />
                <Label htmlFor="fundraising" className="text-sm">
                  Special fundraising campaigns
                </Label>
              </div>
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={isSubmitting}>
            {isSubmitting ? "Subscribing..." : "Subscribe to Newsletter"}
          </Button>

          <p className="text-xs text-muted-foreground">
            We respect your privacy. You can unsubscribe at any time. Read our{" "}
            <a href="/privacy" className="text-primary hover:underline">
              Privacy Policy
            </a>
            .
          </p>
        </form>
      </CardContent>
    </Card>
  )
}
