import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Droplets, GraduationCap, Heart, Zap } from "lucide-react"

const impactStats = [
  {
    icon: Droplets,
    title: "Clean Water Access",
    current: 45000,
    goal: 50000,
    unit: "people",
    color: "text-blue-500",
  },
  {
    icon: GraduationCap,
    title: "Children Educated",
    current: 8500,
    goal: 10000,
    unit: "students",
    color: "text-green-500",
  },
  {
    icon: Heart,
    title: "Healthcare Provided",
    current: 25000,
    goal: 30000,
    unit: "treatments",
    color: "text-red-500",
  },
  {
    icon: Zap,
    title: "Clean Energy Access",
    current: 12000,
    goal: 15000,
    unit: "households",
    color: "text-yellow-500",
  },
]

export function DonationImpact() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Impact This Year</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            See how your donations are making a real difference in communities around the world.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {impactStats.map((stat, index) => {
            const percentage = (stat.current / stat.goal) * 100
            return (
              <Card key={index} className="text-center">
                <CardHeader className="pb-4">
                  <div className="flex justify-center mb-3">
                    <div className="p-3 bg-primary/10 rounded-full">
                      <stat.icon className={`h-8 w-8 ${stat.color}`} />
                    </div>
                  </div>
                  <CardTitle className="text-lg">{stat.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Progress</span>
                      <span className="font-medium">{Math.round(percentage)}%</span>
                    </div>
                    <Progress value={percentage} className="h-2" />
                  </div>
                  <div className="text-2xl font-bold text-foreground">
                    {stat.current.toLocaleString()}
                    <span className="text-sm font-normal text-muted-foreground ml-1">
                      / {stat.goal.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{stat.unit}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>
    </section>
  )
}
