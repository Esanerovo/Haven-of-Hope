"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Play, Volume2, VolumeX } from "lucide-react"

interface VideoTestimonialProps {
  id: string
  name: string
  location: string
  project: string
  videoUrl: string
  thumbnailUrl: string
  quote: string
  duration: string
}

export function VideoTestimonial({
  id,
  name,
  location,
  project,
  videoUrl,
  thumbnailUrl,
  quote,
  duration,
}: VideoTestimonialProps) {
  const [isPlaying, setIsPlaying] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [showVideo, setShowVideo] = useState(false)

  const handlePlayClick = () => {
    setShowVideo(true)
    setIsPlaying(true)
  }

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow">
      <div className="relative aspect-video bg-muted">
        {!showVideo ? (
          // Thumbnail view
          <div className="relative w-full h-full group cursor-pointer" onClick={handlePlayClick}>
            <img
              src={thumbnailUrl || "/placeholder.svg?height=300&width=400&query=person testimonial video"}
              alt={`${name} testimonial`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="bg-primary/90 hover:bg-primary rounded-full p-4 group-hover:scale-110 transition-transform">
                <Play className="h-8 w-8 text-primary-foreground ml-1" />
              </div>
            </div>
            <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm">{duration}</div>
          </div>
        ) : (
          // Video player view
          <div className="relative w-full h-full">
            <video
              className="w-full h-full object-cover"
              controls
              autoPlay
              muted={isMuted}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            >
              <source src={videoUrl} type="video/mp4" />
              Your browser does not support the video tag.
            </video>
            <div className="absolute top-2 right-2 flex gap-2">
              <Button
                size="sm"
                variant="secondary"
                onClick={() => setIsMuted(!isMuted)}
                className="bg-black/70 hover:bg-black/80 text-white"
              >
                {isMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        )}
      </div>

      <CardContent className="p-6">
        <blockquote className="text-muted-foreground italic mb-4 text-pretty">"{quote}"</blockquote>
        <div className="space-y-1">
          <h4 className="font-semibold text-foreground">{name}</h4>
          <p className="text-sm text-muted-foreground">{location}</p>
          <p className="text-sm text-primary font-medium">{project}</p>
        </div>
      </CardContent>
    </Card>
  )
}
