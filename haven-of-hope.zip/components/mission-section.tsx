import { Card, CardContent } from "@/components/ui/card"
import { Lightbulb, HandHeart, TreePine, GraduationCap } from "lucide-react"

export function MissionSection() {
  const missions = [
    {
      icon: HandHeart,
      title: "Community Support",
      description: "Providing essential resources and support to underserved communities worldwide.",
    },
    {
      icon: GraduationCap,
      title: "Education Access",
      description: "Creating educational opportunities and building schools in remote areas.",
    },
    {
      icon: TreePine,
      title: "Environmental Care",
      description: "Implementing sustainable practices and environmental conservation projects.",
    },
    {
      icon: Lightbulb,
      title: "Innovation",
      description: "Developing innovative solutions to address complex social challenges.",
    },
  ]

  return (
    <section className="py-20 bg-card">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Our Mission</h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Dedicated to creativity, culture & growth. We believe in the power of community and the importance of
            sustainable development.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {missions.map((mission, index) => (
            <Card key={index} className="border-border hover:shadow-lg transition-shadow">
              <CardContent className="p-6 text-center">
                <div className="flex justify-center mb-4">
                  <div className="p-3 bg-primary/10 rounded-full">
                    <mission.icon className="h-8 w-8 text-primary" />
                  </div>
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">{mission.title}</h3>
                <p className="text-muted-foreground text-pretty">{mission.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
