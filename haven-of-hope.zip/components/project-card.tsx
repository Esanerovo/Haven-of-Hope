import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { MapPin, Users, Calendar, ArrowRight } from "lucide-react"
import Link from "next/link"

interface ProjectCardProps {
  id: string
  title: string
  description: string
  location: string
  beneficiaries: number
  startDate: string
  status: "active" | "completed" | "upcoming"
  category: string
  image: string
  progress?: number
}

export function ProjectCard({
  id,
  title,
  description,
  location,
  beneficiaries,
  startDate,
  status,
  category,
  image,
  progress,
}: ProjectCardProps) {
  const statusColors = {
    active: "bg-primary text-primary-foreground",
    completed: "bg-green-500 text-white",
    upcoming: "bg-orange-500 text-white",
  }

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow group">
      <div className="relative h-48 overflow-hidden">
        <img
          src={image || "/placeholder.svg"}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute top-4 left-4">
          <Badge className={statusColors[status]}>{status.charAt(0).toUpperCase() + status.slice(1)}</Badge>
        </div>
        <div className="absolute top-4 right-4">
          <Badge variant="secondary">{category}</Badge>
        </div>
      </div>

      <CardHeader>
        <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">{title}</h3>
      </CardHeader>

      <CardContent className="space-y-4">
        <p className="text-muted-foreground text-pretty">{description}</p>

        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />
            <span>{location}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="h-4 w-4" />
            <span>{beneficiaries.toLocaleString()} beneficiaries</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Calendar className="h-4 w-4" />
            <span>Started {startDate}</span>
          </div>
        </div>

        {progress !== undefined && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">{progress}%</span>
            </div>
            <div className="w-full bg-secondary rounded-full h-2">
              <div
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        )}

        <Button variant="outline" className="w-full group/btn bg-transparent" asChild>
          <Link href={`/projects/${id}`}>
            Learn More
            <ArrowRight className="h-4 w-4 ml-2 group-hover/btn:translate-x-1 transition-transform" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  )
}
