import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { DonationForm } from "@/components/donation-form"
import { DonationImpact } from "@/components/donation-impact"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Heart, Shield, Users, Globe } from "lucide-react"
import Link from "next/link"

export default function DonatePage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-b from-primary/5 to-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Button variant="ghost" asChild className="mb-6">
            <Link href="/" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Link>
          </Button>

          <div className="text-center mb-12">
            <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Make a Difference Today</h1>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
              Your donation helps us bring hope, education, clean water, and sustainable development to communities
              worldwide. Every contribution makes a lasting impact.
            </p>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Shield className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="font-semibold text-foreground mb-2">Secure Donations</h3>
              <p className="text-sm text-muted-foreground">256-bit SSL encryption</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Heart className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="font-semibold text-foreground mb-2">Tax Deductible</h3>
              <p className="text-sm text-muted-foreground">501(c)(3) nonprofit</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Users className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="font-semibold text-foreground mb-2">Direct Impact</h3>
              <p className="text-sm text-muted-foreground">90% goes to programs</p>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <div className="p-3 bg-primary/10 rounded-full">
                  <Globe className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="font-semibold text-foreground mb-2">Global Reach</h3>
              <p className="text-sm text-muted-foreground">25 countries served</p>
            </div>
          </div>
        </div>
      </section>

      {/* Donation Form */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <DonationForm />
        </div>
      </section>

      {/* Impact Statistics */}
      <DonationImpact />

      <Footer />
    </main>
  )
}
