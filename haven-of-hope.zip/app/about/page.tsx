import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowLeft, Target, Eye, Award } from "lucide-react"
import Link from "next/link"

const teamMembers = [
  {
    name: "Sarah Johnson",
    role: "Executive Director",
    image: "/sarah-johnson-executive-director.jpg",
    bio: "Sarah has over 15 years of experience in international development and has led Haven of Hope since its founding.",
  },
  {
    name: "Michael Chen",
    role: "Program Director",
    image: "/michael-chen-program-director.jpg",
    bio: "Michael oversees our field operations and ensures our projects meet the highest standards of impact and sustainability.",
  },
  {
    name: "Dr. Amara Okafor",
    role: "Medical Advisor",
    image: "/amara-okafor-medical-advisor.jpg",
    bio: "Dr. Okafor brings 20 years of healthcare experience and guides our health and wellness initiatives worldwide.",
  },
  {
    name: "James Rodriguez",
    role: "Community Outreach",
    image: "/james-rodriguez-community-outreach.jpg",
    bio: "James builds relationships with local communities and ensures our projects are culturally appropriate and sustainable.",
  },
]

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>

        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">About Haven of Hope</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Founded in 2010, Haven of Hope is dedicated to creating lasting positive change in underserved communities
            worldwide through sustainable development, education, and community empowerment.
          </p>
        </div>

        {/* Mission, Vision, Values */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                Our Mission
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-pretty">
                To empower communities worldwide by providing sustainable solutions for education, healthcare, clean
                water, and economic development while fostering local leadership and self-reliance.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5 text-primary" />
                Our Vision
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground text-pretty">
                A world where every community has access to the resources and opportunities needed to thrive, creating a
                future filled with hope, dignity, and sustainable prosperity for all.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5 text-primary" />
                Our Values
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="text-muted-foreground space-y-2 text-sm">
                <li>• Transparency and accountability</li>
                <li>• Community-led development</li>
                <li>• Cultural respect and sensitivity</li>
                <li>• Environmental sustainability</li>
                <li>• Innovation and adaptability</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Our Story */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Our Story</h2>
          <div className="max-w-4xl mx-auto space-y-6 text-muted-foreground">
            <p className="text-lg text-pretty">
              Haven of Hope was founded in 2010 by a group of passionate individuals who witnessed firsthand the
              challenges faced by underserved communities around the world. What started as a small initiative to build
              a single school in rural Guatemala has grown into a global organization impacting lives across 25
              countries.
            </p>
            <p className="text-pretty">
              Our approach is rooted in the belief that sustainable change comes from within communities themselves. We
              work closely with local leaders, organizations, and residents to identify needs, develop solutions, and
              implement projects that create lasting impact. Every initiative is designed with community ownership and
              long-term sustainability in mind.
            </p>
            <p className="text-pretty">
              Over the past 15 years, we've learned that the most effective development work happens when communities
              are empowered to lead their own transformation. Our role is to provide resources, expertise, and support
              while ensuring that local voices guide every decision and local hands build every solution.
            </p>
          </div>
        </div>

        {/* Team */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {teamMembers.map((member, index) => (
              <Card key={index} className="text-center">
                <CardContent className="p-6">
                  <div className="w-24 h-24 mx-auto mb-4 rounded-full overflow-hidden bg-muted">
                    <img
                      src={member.image || "/placeholder.svg?height=96&width=96&query=professional headshot"}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-semibold text-foreground mb-1">{member.name}</h3>
                  <p className="text-sm text-primary font-medium mb-3">{member.role}</p>
                  <p className="text-sm text-muted-foreground text-pretty">{member.bio}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Impact Numbers */}
        <div className="bg-primary/5 rounded-lg p-8 mb-16">
          <h2 className="text-3xl font-bold text-foreground mb-8 text-center">Our Impact by the Numbers</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <div className="text-3xl font-bold text-primary mb-2">50,000+</div>
              <div className="text-muted-foreground">Lives Impacted</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">25</div>
              <div className="text-muted-foreground">Countries</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">150+</div>
              <div className="text-muted-foreground">Active Projects</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-primary mb-2">500+</div>
              <div className="text-muted-foreground">Local Partners</div>
            </div>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-foreground mb-4">Join Our Mission</h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto text-pretty">
            Whether through donations, volunteering, or partnerships, there are many ways to be part of creating
            positive change in the world.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" asChild>
              <Link href="/donate">Make a Donation</Link>
            </Button>
            <Button variant="outline" size="lg" asChild>
              <Link href="/contact">Get Involved</Link>
            </Button>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
