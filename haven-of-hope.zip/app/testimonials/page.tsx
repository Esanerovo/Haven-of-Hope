import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { TestimonialsSection } from "@/components/testimonials-section"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function TestimonialsPage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>

        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Success Stories</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Watch and listen to the powerful stories from communities around the world who have been impacted by our
            projects and your generous support.
          </p>
        </div>
      </div>

      <TestimonialsSection />
      <Footer />
    </main>
  )
}
