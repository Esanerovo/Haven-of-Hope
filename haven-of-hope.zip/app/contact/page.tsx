import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ContactForm } from "@/components/contact-form"
import { NewsletterSignup } from "@/components/newsletter-signup"
import { Button } from "@/components/ui/button"
import { ArrowLeft, MessageCircle, Users, Handshake, Calendar } from "lucide-react"
import Link from "next/link"

export default function ContactPage() {
  return (
    <main className="min-h-screen">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </Button>

        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Get in Touch</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            We'd love to hear from you. Whether you have questions about our work, want to volunteer, or are interested
            in partnerships, we're here to help.
          </p>
        </div>

        {/* Contact Options */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <div className="text-center p-6 rounded-lg bg-card border border-border">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <MessageCircle className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="font-semibold text-foreground mb-2">General Inquiries</h3>
            <p className="text-sm text-muted-foreground">Questions about our work and impact</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-card border border-border">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <Users className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="font-semibold text-foreground mb-2">Volunteer</h3>
            <p className="text-sm text-muted-foreground">Join our team and make a difference</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-card border border-border">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <Handshake className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="font-semibold text-foreground mb-2">Partnerships</h3>
            <p className="text-sm text-muted-foreground">Collaborate with us on projects</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-card border border-border">
            <div className="flex justify-center mb-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
            </div>
            <h3 className="font-semibold text-foreground mb-2">Events</h3>
            <p className="text-sm text-muted-foreground">Speaking and event opportunities</p>
          </div>
        </div>

        {/* Contact Form */}
        <div className="mb-16">
          <ContactForm />
        </div>

        {/* Newsletter Signup */}
        <div className="max-w-2xl mx-auto">
          <NewsletterSignup />
        </div>
      </div>

      <Footer />
    </main>
  )
}
