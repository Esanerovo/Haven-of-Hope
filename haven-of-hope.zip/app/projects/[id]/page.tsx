import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, MapPin, Users, Calendar, Target, Heart } from "lucide-react"
import Link from "next/link"
import { notFound } from "next/navigation"

// Mock project data (in a real app, this would come from a database)
const projects = {
  "1": {
    id: "1",
    title: "Clean Water Initiative",
    description:
      "Building sustainable water systems and wells in rural communities to provide clean, safe drinking water for families.",
    fullDescription:
      "Our Clean Water Initiative focuses on creating lasting solutions for water scarcity in rural Kenya. We work closely with local communities to identify the best locations for wells and water systems, ensuring they are sustainable and maintainable by the community members themselves. The project includes training local technicians, establishing water committees, and implementing water quality monitoring systems.",
    location: "Kenya, East Africa",
    beneficiaries: 5000,
    startDate: "March 2024",
    endDate: "December 2024",
    status: "active" as const,
    category: "Water & Sanitation",
    image: "/clean-water-well-in-african-village.jpg",
    progress: 75,
    budget: 150000,
    raised: 112500,
    goals: [
      "Construct 15 water wells in rural communities",
      "Train 50 local water technicians",
      "Establish 15 community water committees",
      "Provide clean water access to 5,000 people",
    ],
    updates: [
      {
        date: "September 2024",
        title: "Major Milestone Reached",
        content:
          "We have successfully completed 11 out of 15 planned water wells, providing clean water access to over 3,500 people.",
      },
      {
        date: "July 2024",
        title: "Community Training Program",
        content: "Completed training for 35 local water technicians who will maintain the water systems long-term.",
      },
    ],
  },
}

interface ProjectDetailPageProps {
  params: Promise<{ id: string }>
}

export default async function ProjectDetailPage({ params }: ProjectDetailPageProps) {
  const { id } = await params
  const project = projects[id as keyof typeof projects]

  if (!project) {
    notFound()
  }

  const statusColors = {
    active: "bg-primary text-primary-foreground",
    completed: "bg-green-500 text-white",
    upcoming: "bg-orange-500 text-white",
  }

  const progressPercentage = (project.raised / project.budget) * 100

  return (
    <main className="min-h-screen">
      <Navigation />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Back Button */}
        <Button variant="ghost" asChild className="mb-6">
          <Link href="/projects" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Projects
          </Link>
        </Button>

        {/* Hero Image */}
        <div className="relative h-64 md:h-96 rounded-lg overflow-hidden mb-8">
          <img src={project.image || "/placeholder.svg"} alt={project.title} className="w-full h-full object-cover" />
          <div className="absolute top-4 left-4">
            <Badge className={statusColors[project.status]}>
              {project.status.charAt(0).toUpperCase() + project.status.slice(1)}
            </Badge>
          </div>
          <div className="absolute top-4 right-4">
            <Badge variant="secondary">{project.category}</Badge>
          </div>
        </div>

        {/* Project Header */}
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">{project.title}</h1>
          <p className="text-xl text-muted-foreground mb-6 text-pretty">{project.fullDescription}</p>

          {/* Project Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="flex items-center gap-2 text-muted-foreground">
              <MapPin className="h-5 w-5" />
              <span>{project.location}</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Users className="h-5 w-5" />
              <span>{project.beneficiaries.toLocaleString()} beneficiaries</span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Calendar className="h-5 w-5" />
              <span>
                {project.startDate} - {project.endDate}
              </span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Target className="h-5 w-5" />
              <span>{project.progress}% complete</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Project Goals */}
            <Card>
              <CardHeader>
                <CardTitle>Project Goals</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {project.goals.map((goal, index) => (
                    <li key={index} className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span className="text-muted-foreground">{goal}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            {/* Project Updates */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Updates</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {project.updates.map((update, index) => (
                  <div key={index} className="border-l-2 border-primary pl-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-semibold text-foreground">{update.title}</span>
                      <span className="text-sm text-muted-foreground">{update.date}</span>
                    </div>
                    <p className="text-muted-foreground text-pretty">{update.content}</p>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Progress Card */}
            <Card>
              <CardHeader>
                <CardTitle>Project Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Completion</span>
                    <span className="font-medium">{project.progress}%</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-3">
                    <div
                      className="bg-primary h-3 rounded-full transition-all duration-300"
                      style={{ width: `${project.progress}%` }}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Funding Card */}
            <Card>
              <CardHeader>
                <CardTitle>Funding Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Raised</span>
                    <span className="font-bold text-foreground">${project.raised.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Goal</span>
                    <span className="font-medium">${project.budget.toLocaleString()}</span>
                  </div>
                  <div className="w-full bg-secondary rounded-full h-3">
                    <div
                      className="bg-green-500 h-3 rounded-full transition-all duration-300"
                      style={{ width: `${progressPercentage}%` }}
                    />
                  </div>
                  <p className="text-sm text-muted-foreground">{Math.round(progressPercentage)}% funded</p>
                </div>

                <Button className="w-full" asChild>
                  <Link href="/donate" className="flex items-center gap-2">
                    <Heart className="h-4 w-4" />
                    Support This Project
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
