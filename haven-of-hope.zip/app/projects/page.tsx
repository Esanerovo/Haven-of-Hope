"use client"

import { useState, useMemo } from "react"
import { Navigation } from "@/components/navigation"
import { Footer } from "@/components/footer"
import { ProjectCard } from "@/components/project-card"
import { ProjectFilters } from "@/components/project-filters"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

// Mock project data
const projects = [
  {
    id: "1",
    title: "Clean Water Initiative",
    description:
      "Building sustainable water systems and wells in rural communities to provide clean, safe drinking water for families.",
    location: "Kenya, East Africa",
    beneficiaries: 5000,
    startDate: "March 2024",
    status: "active" as const,
    category: "Water & Sanitation",
    image: "/clean-water-well-in-african-village.jpg",
    progress: 75,
  },
  {
    id: "2",
    title: "Education for All",
    description: "Constructing schools and providing educational resources to underserved communities worldwide.",
    location: "Guatemala, Central America",
    beneficiaries: 1200,
    startDate: "January 2024",
    status: "active" as const,
    category: "Education",
    image: "/children-in-classroom-school-guatemala.jpg",
    progress: 60,
  },
  {
    id: "3",
    title: "Sustainable Agriculture",
    description: "Teaching modern farming techniques and providing seeds and tools to improve food security.",
    location: "Bangladesh, South Asia",
    beneficiaries: 3500,
    startDate: "November 2023",
    status: "completed" as const,
    category: "Agriculture",
    image: "/sustainable-farming-bangladesh-rice-fields.jpg",
  },
  {
    id: "4",
    title: "Healthcare Access",
    description: "Establishing mobile clinics and training local healthcare workers in remote areas.",
    location: "Madagascar, Africa",
    beneficiaries: 8000,
    startDate: "June 2024",
    status: "upcoming" as const,
    category: "Healthcare",
    image: "/mobile-healthcare-clinic-madagascar.jpg",
  },
  {
    id: "5",
    title: "Renewable Energy",
    description: "Installing solar panels and wind turbines to bring clean energy to off-grid communities.",
    location: "Peru, South America",
    beneficiaries: 2800,
    startDate: "February 2024",
    status: "active" as const,
    category: "Energy",
    image: "/solar-panels-mountain-village-peru.jpg",
    progress: 40,
  },
  {
    id: "6",
    title: "Women Empowerment",
    description: "Providing vocational training and microfinance opportunities for women entrepreneurs.",
    location: "India, South Asia",
    beneficiaries: 1500,
    startDate: "October 2023",
    status: "completed" as const,
    category: "Economic Development",
    image: "/women-entrepreneurs-india-workshop.jpg",
  },
]

const categories = [...new Set(projects.map((p) => p.category))]
const statuses = [...new Set(projects.map((p) => p.status))]

export default function ProjectsPage() {
  const [filters, setFilters] = useState({
    search: "",
    category: "all",
    status: "all",
  })

  const filteredProjects = useMemo(() => {
    return projects.filter((project) => {
      const matchesSearch =
        project.title.toLowerCase().includes(filters.search.toLowerCase()) ||
        project.description.toLowerCase().includes(filters.search.toLowerCase()) ||
        project.location.toLowerCase().includes(filters.search.toLowerCase())

      const matchesCategory = filters.category === "all" || project.category === filters.category
      const matchesStatus = filters.status === "all" || project.status === filters.status

      return matchesSearch && matchesCategory && matchesStatus
    })
  }, [filters])

  return (
    <main className="min-h-screen">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Header */}
        <div className="mb-8">
          <Button variant="ghost" asChild className="mb-4">
            <Link href="/" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Home
            </Link>
          </Button>

          <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-4">Our Projects</h1>
          <p className="text-xl text-muted-foreground max-w-3xl text-pretty">
            Discover the impact we're making around the world through our various initiatives and community projects.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <div className="sticky top-24">
              <ProjectFilters categories={categories} statuses={statuses} onFilterChange={setFilters} />
            </div>
          </div>

          {/* Projects Grid */}
          <div className="lg:col-span-3">
            <div className="mb-6">
              <p className="text-muted-foreground">
                Showing {filteredProjects.length} of {projects.length} projects
              </p>
            </div>

            {filteredProjects.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {filteredProjects.map((project) => (
                  <ProjectCard key={project.id} {...project} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg">No projects found matching your criteria.</p>
                <Button
                  variant="outline"
                  onClick={() => setFilters({ search: "", category: "all", status: "all" })}
                  className="mt-4"
                >
                  Clear Filters
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <Footer />
    </main>
  )
}
